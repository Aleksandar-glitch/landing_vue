import { createRouter, createWebHistory } from 'vue-router'

// Import your components here
import About from '../components/About.vue'

// Define your routes
const routes = [
  {
    path: '/about',
    name: 'About',
    component: About
  }
]

// Create the router instance using history mode
const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
