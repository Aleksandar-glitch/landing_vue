const themeColor = '#407BFF'
const siteName = 'Launch'

const contactInfo = {
    address: '43 Raymouth Rd. Baltemoer, London 3910',
    phone1: '+1(123)-456-7890',
    phone2: '+1(123)-456-7890',
    email: 'info@mydomain.com',
    website: 'https://yourwebsite.com/'
}

export { themeColor, siteName, contactInfo }