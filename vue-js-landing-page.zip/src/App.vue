<script setup>
import Header from "./components/Header.vue";
import Hero from "./components/Hero.vue";
import Managers from "./components/Managers.vue";
import Vimeo from "./components/Vimeo.vue";
import Visitors from "./components/Visitors.vue";
import Reason from "./components/Reason.vue";
import Exposure from "./components/Exposure.vue";
import Residents from "./components/Residents.vue";
import Walkability from "./components/Walkability.vue";
import Testimonial from "./components/Testimonial.vue";
import Lifestyle from "./components/Lifestyle.vue";
import ContactFooter from "./components/ContactFooter.vue";
</script>

<template>
  <Header />
  <Hero />
  <Managers />
  <Vimeo />
  <Visitors />
  <Reason />
  <Exposure />
  <Residents />
  <Walkability />
  <Testimonial />
  <!-- <Lifestyle /> -->
  <ContactFooter />
</template>
